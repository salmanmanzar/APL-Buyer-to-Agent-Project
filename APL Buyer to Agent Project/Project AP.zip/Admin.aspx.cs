﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace APL_Buyer_to_Agent_Project
{
    public partial class Admin : Page
    {
        private string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["real_estateConnectionString"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                DisplayMessage();
            }
        }

        private void DisplayMessage()
        {
            if (Session["BuyerMessage"] != null)
            {
                lblMessage.Text = "Message from Buyer:";
                adminMessage.Text = Session["BuyerMessage"].ToString();
                Session["BuyerMessage"] = null;
                btnSendToBuyer.Visible = false;
                btnSendToAgent.Visible = true;
            }
            else if (Session["AgentMessage"] != null)
            {
                lblMessage.Text = "Message from Agent:";
                adminMessage.Text = Session["AgentMessage"].ToString();
                Session["AgentMessage"] = null;
                btnSendToAgent.Visible = false;
                btnSendToBuyer.Visible = true;
            }
            else if (Session["AdminToAgentMessage"] != null)
            {
                lblMessage.Text = "Message to Agent:";
                adminMessage.Text = Session["AdminToAgentMessage"].ToString();
                Session["AdminToAgentMessage"] = null;
                btnSendToAgent.Visible = false;
                btnSendToBuyer.Visible = false;
            }
            else if (Session["AdminToBuyerMessage"] != null)
            {
                lblMessage.Text = "Message to Buyer:";
                adminMessage.Text = Session["AdminToBuyerMessage"].ToString();
                Session["AdminToBuyerMessage"] = null;
                btnSendToAgent.Visible = false;
                btnSendToBuyer.Visible = false;
            }
            else
            {
                lblMessage.Text = "No new messages.";
                adminMessage.Visible = false;
            }
        }

        protected void btnEdit_Click(object sender, EventArgs e)
        {
            adminMessage.ReadOnly = false;
        }

        protected void btnSendToAgent_Click(object sender, EventArgs e)
        {
            string adminMessageText = adminMessage.Text.Trim();

            if (string.IsNullOrEmpty(adminMessageText))
            {
                return;
            }

            SaveMessageToDatabase("Admin", "Agent", adminMessageText, adminMessage.ReadOnly);
            adminMessage.ReadOnly = true;
            Session["AdminToAgentMessage"] = adminMessageText;
            Response.Redirect("Agentform.aspx");
        }

        protected void btnSendToBuyer_Click(object sender, EventArgs e)
        {
            string adminMessageText = adminMessage.Text.Trim();

            if (string.IsNullOrEmpty(adminMessageText))
            {
                return;
            }

            SaveMessageToDatabase("Admin", "Buyer", adminMessageText, adminMessage.ReadOnly);
            adminMessage.ReadOnly = true;
            Session["AdminToBuyerMessage"] = adminMessageText;
            Response.Redirect("Buyerform.aspx");
        }

        private void SaveMessageToDatabase(string sender, string receiver, string messageText, bool isEdited)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO realestate_table (Sender, Receiver, MessageText, IsEdited) VALUES (@Sender, @Receiver, @MessageText, @IsEdited)";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Sender", sender);
                command.Parameters.AddWithValue("@Receiver", receiver);
                command.Parameters.AddWithValue("@MessageText", messageText);
                command.Parameters.AddWithValue("@IsEdited", isEdited);

                connection.Open();
                command.ExecuteNonQuery();
            }
        }
        

    }
}